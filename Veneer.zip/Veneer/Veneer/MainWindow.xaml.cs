﻿using System;
using System.Windows;
using Veneer.DataAccess;
using Veneer.Helpers;
using Veneer.Views;

namespace Veneer
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                txtStatus.Text = "Заполните логин и пароль";
                txtStatus.Foreground = System.Windows.Media.Brushes.Red;
                return;
            }

            try
            {
                // Временная отладка
                MessageBox.Show("Логин: " + login + "\nПароль: " + password);

                var user = AuthService.Authenticate(login, password);

                if (user != null)
                {
                    MessageBox.Show("Успешный вход! Роль: " + user.RoleName);
                    SessionManager.CurrentUser = user;
                    OpenRoleWindow(user.RoleName);
                }
                else
                {
                    MessageBox.Show("Пользователь не найден");
                    txtStatus.Text = "Неверный логин или пароль";
                    txtStatus.Foreground = System.Windows.Media.Brushes.Red;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
                txtStatus.Text = "Ошибка подключения к БД: " + ex.Message;
                txtStatus.Foreground = System.Windows.Media.Brushes.Red;
            }
        }

        private void OpenRoleWindow(string roleName)
        {
            Window window = null;

            switch (roleName)
            {
                case "Admin":
                    window = new AdminWindow();
                    break;
                case "Technologist":
                    window = new TechnologistWindow();
                    break;
                case "Operator":
                    window = new OperatorWindow();
                    break;
                case "Storekeeper":
                    window = new StorekeeperWindow();
                    break;
                default:
                    window = new OperatorWindow();
                    break;
            }

            window.Show();
            this.Close();
        }
    }
}