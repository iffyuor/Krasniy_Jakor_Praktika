﻿namespace Veneer.Models
{
    public class User
    {
        public int UserID { get; set; }
        public int EmployeeID { get; set; }
        public string FullName { get; set; }
        public int RoleID { get; set; }
        public string RoleName { get; set; }
        public string Login { get; set; }
    }
}