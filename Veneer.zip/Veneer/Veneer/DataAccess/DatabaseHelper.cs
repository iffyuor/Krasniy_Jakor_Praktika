﻿using System;
using System.Data.SqlClient;
using System.IO;

namespace Veneer.DataAccess
{
    public static class DatabaseHelper
    {
        private static string connectionString = "Server=localhost;Database=ProductionVeneer;User Id=timbd;Password=TimBd12345!;";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        public static string GetBackupFolder()
        {
            string folder = @"G:\Server\MSSQL15.MSSQLSERVER\MSSQL\Backup\";

            // Создаём папку, если её нет
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            return folder;
        }

        public static void CreateBackup(string backupPath)
        {
            using (SqlConnection conn = GetConnection())
            {
                conn.Open();
                string query = $"BACKUP DATABASE ProductionVeneer TO DISK = '{backupPath}' WITH INIT, STATS = 10";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
            }
        }
    }
}