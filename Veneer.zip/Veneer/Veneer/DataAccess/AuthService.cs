﻿using System.Data.SqlClient;
using Veneer.Models;

namespace Veneer.DataAccess
{
    public static class AuthService
    {
        public static User Authenticate(string login, string password)
        {
            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = @"
                    SELECT u.UserID, u.EmployeeID, e.FullName, u.RoleID, r.RoleName, u.Login
                    FROM AppUser u
                    JOIN Employee e ON u.EmployeeID = e.EmployeeID
                    JOIN Role r ON u.RoleID = r.RoleID
                    WHERE u.Login = @login AND u.PasswordHash = @password AND u.IsActive = 1";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@login", login);
                cmd.Parameters.AddWithValue("@password", password);

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    return new User
                    {
                        UserID = reader.GetInt32(0),
                        EmployeeID = reader.GetInt32(1),
                        FullName = reader.GetString(2),
                        RoleID = reader.GetInt32(3),
                        RoleName = reader.GetString(4),
                        Login = reader.GetString(5)
                    };
                }
                return null;
            }
        }
    }
}