﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Veneer.DataAccess;
using Veneer.Helpers;
using Microsoft.Win32;


namespace Veneer.Views
{
    public partial class AdminWindow : Window
    {
        public AdminWindow()
        {
            InitializeComponent();
            txtUserInfo.Text = SessionManager.CurrentUser.FullName + " | Администратор";
            LoadUsers();
        }

        private void LoadUsers()
        {
            DataTable dt = new DataTable();
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = @"
                    SELECT u.UserID, u.Login, r.RoleName, e.FullName, 
                           CASE WHEN u.IsActive = 1 THEN 'Активен' ELSE 'Заблокирован' END AS Status
                    FROM AppUser u
                    JOIN Role r ON u.RoleID = r.RoleID
                    JOIN Employee e ON u.EmployeeID = e.EmployeeID";

                var adapter = new System.Data.SqlClient.SqlDataAdapter(query, conn);
                adapter.Fill(dt);
            }

            DataGrid grid = CreateDataGrid();
            grid.AutoGenerateColumns = false;
            grid.ItemsSource = dt.DefaultView;

            AddColumn(grid, "UserID", "ID");
            AddColumn(grid, "Login", "Логин");
            AddColumn(grid, "RoleName", "Роль", (value) => TextMapper.GetRoleName(value.ToString()));
            AddColumn(grid, "FullName", "Сотрудник");
            AddColumn(grid, "Status", "Статус");

            contentArea.Child = grid;
        }

        private void LoadRoles()
        {
            DataTable dt = new DataTable();
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT RoleID, RoleName FROM Role";
                var adapter = new System.Data.SqlClient.SqlDataAdapter(query, conn);
                adapter.Fill(dt);
            }

            DataGrid grid = CreateDataGrid();
            grid.AutoGenerateColumns = false;
            grid.ItemsSource = dt.DefaultView;

            AddColumn(grid, "RoleID", "ID");
            AddColumn(grid, "RoleName", "Роль", (value) => TextMapper.GetRoleName(value.ToString()));

            contentArea.Child = grid;
        }

        private void AddColumn(DataGrid grid, string bindingPath, string header, System.Func<object, string> converter = null)
        {
            DataGridTextColumn column = new DataGridTextColumn();
            column.Header = header;
            column.Binding = new System.Windows.Data.Binding(bindingPath);

            if (converter != null)
            {
                // Для конвертера нужно будет доработать, пока просто выводим как есть
            }

            grid.Columns.Add(column);
        }

        private DataGrid CreateDataGrid()
        {
            DataGrid grid = new DataGrid();
            grid.IsReadOnly = true;
            grid.FontSize = 12;
            grid.RowHeight = 30;
            grid.HeadersVisibility = DataGridHeadersVisibility.Column;
            grid.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
            grid.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            return grid;
        }

        private void BtnUsers_Click(object sender, RoutedEventArgs e)
        {
            var window = new AdminUsersWindow();
            window.Owner = this;
            window.ShowDialog();
            LoadUsers(); // Обновляем отображение после закрытия
        }

        private void BtnRoles_Click(object sender, RoutedEventArgs e)
        {
            var window = new AdminRolesWindow();
            window.Owner = this;
            window.ShowDialog();
            LoadRoles();
        }
        private void BtnBackup_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Открываем диалог сохранения файла
                Microsoft.Win32.SaveFileDialog dialog = new Microsoft.Win32.SaveFileDialog();
                dialog.Title = "Сохранить резервную копию";
                dialog.Filter = "Backup files (*.bak)|*.bak|All files (*.*)|*.*";
                dialog.DefaultExt = ".bak";
                dialog.FileName = "ProductionVeneer_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".bak";

                bool? result = dialog.ShowDialog();

                if (result == true)
                {
                    string backupPath = dialog.FileName;

                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();
                        string query = $"BACKUP DATABASE ProductionVeneer TO DISK = '{backupPath}' WITH INIT";
                        var cmd = new System.Data.SqlClient.SqlCommand(query, conn);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Резервная копия создана:\n" + backupPath, "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при создании бэкапа:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnReports_Click(object sender, RoutedEventArgs e)
        {
            StackPanel stack = new StackPanel();

            TextBlock title = new TextBlock();
            title.Text = "Отчёты";
            title.FontSize = 16;
            title.FontWeight = FontWeights.Bold;
            stack.Children.Add(title);

            Button btnLogReport = new Button();
            btnLogReport.Content = "Отчёт по брёвнам";
            btnLogReport.Height = 35;
            btnLogReport.Margin = new System.Windows.Thickness(0, 5, 0, 0);
            btnLogReport.Click += (s, ev) => ShowReport("LogBatch", "Брёвна");
            stack.Children.Add(btnLogReport);

            Button btnVeneerReport = new Button();
            btnVeneerReport.Content = "Отчёт по шпону";
            btnVeneerReport.Height = 35;
            btnVeneerReport.Margin = new System.Windows.Thickness(0, 5, 0, 0);
            btnVeneerReport.Click += (s, ev) => ShowReport("VeneerBatch", "Шпон");
            stack.Children.Add(btnVeneerReport);

            Button btnSemiReport = new Button();
            btnSemiReport.Content = "Отчёт по полуфабрикату";
            btnSemiReport.Height = 35;
            btnSemiReport.Margin = new System.Windows.Thickness(0, 5, 0, 0);
            btnSemiReport.Click += (s, ev) => ShowReport("SemiFinishedBatch", "Полуфабрикат");
            stack.Children.Add(btnSemiReport);

            Button btnFinishedReport = new Button();
            btnFinishedReport.Content = "Отчёт по готовой фанере";
            btnFinishedReport.Height = 35;
            btnFinishedReport.Margin = new System.Windows.Thickness(0, 5, 0, 0);
            btnFinishedReport.Click += (s, ev) => ShowReport("FinishedBatch", "Готовая фанера");
            stack.Children.Add(btnFinishedReport);

            contentArea.Child = stack;
        }
        private void ShowReport(string tableName, string title)
        {
            DataTable dt = new DataTable();
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = $"SELECT TOP 100 * FROM {tableName} ORDER BY 1 DESC";
                var adapter = new System.Data.SqlClient.SqlDataAdapter(query, conn);
                adapter.Fill(dt);
            }

            DataGrid grid = CreateDataGrid();
            grid.AutoGenerateColumns = true;
            grid.ItemsSource = dt.DefaultView;
            grid.MinWidth = 800;
            grid.MaxHeight = 450;

            // Оборачиваем DataGrid в ScrollViewer для прокрутки
            ScrollViewer scrollViewer = new ScrollViewer();
            scrollViewer.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
            scrollViewer.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            scrollViewer.Content = grid;

            StackPanel stack = new StackPanel();
            TextBlock titleBlock = new TextBlock();
            titleBlock.Text = title;
            titleBlock.FontSize = 14;
            titleBlock.FontWeight = FontWeights.Bold;
            titleBlock.Margin = new Thickness(0, 0, 0, 10);
            stack.Children.Add(titleBlock);
            stack.Children.Add(scrollViewer);

            contentArea.Child = stack;
        }

        // Вспомогательный метод для поиска ScrollViewer внутри DataGrid
        private ScrollViewer FindScrollViewer(DependencyObject parent)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is ScrollViewer)
                    return (ScrollViewer)child;

                var result = FindScrollViewer(child);
                if (result != null)
                    return result;
            }
            return null;
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            SessionManager.Clear();
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}