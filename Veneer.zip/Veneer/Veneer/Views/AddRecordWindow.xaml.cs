﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Data.SqlClient;
using Veneer.DataAccess;

namespace Veneer.Views
{
    public partial class AddRecordWindow : Window
    {
        public AddRecordWindow()
        {
            InitializeComponent();
            LoadFieldsForLog();
        }

        private void CmbProductType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            pnlFields.Children.Clear();
            int index = cmbProductType.SelectedIndex;

            switch (index)
            {
                case 0:
                    LoadFieldsForLog();
                    break;
                case 1:
                    LoadFieldsForVeneer();
                    break;
                case 2:
                    LoadFieldsForSemi();
                    break;
                case 3:
                    LoadFieldsForFinished();
                    break;
            }
        }

        private void LoadFieldsForLog()
        {
            AddField("BatchNumber", "Номер партии");
            AddField("QuantityReceived", "Объём (м³)");
            AddField("QualityClass", "Сорт (1-3)");
        }

        private void LoadFieldsForVeneer()
        {
            AddField("BatchNumber", "Номер партии");
            AddField("Thickness_mm", "Толщина (мм)");
            AddField("SheetsProduced", "Количество листов");
        }

        private void LoadFieldsForSemi()
        {
            AddField("BatchNumber", "Номер партии");
            AddField("LayersCount", "Количество слоёв");
            AddField("SheetsProduced", "Количество листов");
        }

        private void LoadFieldsForFinished()
        {
            AddField("BatchNumber", "Номер партии");
            AddField("FinalThickness_mm", "Толщина (мм)");
            AddField("SheetsProduced", "Количество листов");
        }

        private void AddField(string name, string label)
        {
            var stack = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
            stack.Children.Add(new TextBlock { Text = label, Margin = new Thickness(0, 0, 0, 5) });
            var textBox = new TextBox { Name = name, Height = 30 };
            stack.Children.Add(textBox);
            pnlFields.Children.Add(stack);
        }

        private TextBox GetField(string name)
        {
            foreach (StackPanel panel in pnlFields.Children)
            {
                foreach (var child in panel.Children)
                {
                    if (child is TextBox tb && tb.Name == name)
                        return tb;
                }
            }
            return null;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int index = cmbProductType.SelectedIndex;
                string batchNumber = GetField("BatchNumber")?.Text;

                if (string.IsNullOrEmpty(batchNumber))
                {
                    MessageBox.Show("Введите номер партии", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = "";

                    if (index == 0)
                    {
                        string quantity = GetField("QuantityReceived")?.Text;
                        string quality = GetField("QualityClass")?.Text;
                        query = $@"
                            INSERT INTO LogBatch (BatchNumber, SupplierID, TimberTypeID, UnitID, QuantityReceived, QualityClass, ReceiptDate, Status)
                            VALUES ('{batchNumber}', 1, 1, 1, {quantity}, {quality}, GETDATE(), 'На складе')";
                    }
                    else if (index == 1)
                    {
                        string thickness = GetField("Thickness_mm")?.Text;
                        string sheets = GetField("SheetsProduced")?.Text;
                        query = $@"
                            INSERT INTO VeneerBatch (BatchNumber, LogBatchID, UnitID, Thickness_mm, SheetsProduced, ProductionDate, OperatorID, Status)
                            VALUES ('{batchNumber}', 1, 2, {thickness}, {sheets}, GETDATE(), 3, 'Произведён')";
                    }
                    else if (index == 2)
                    {
                        string layers = GetField("LayersCount")?.Text;
                        string sheets = GetField("SheetsProduced")?.Text;
                        query = $@"
                            INSERT INTO SemiFinishedBatch (BatchNumber, VeneerBatchID, UnitID, PressingDateTime, LayersCount, GlueType, Pressure_atm, Temperature_C, SheetsProduced, OperatorID, Status)
                            VALUES ('{batchNumber}', 1, 2, GETDATE(), {layers}, 'СФК', 10, 140, {sheets}, 3, 'Готов')";
                    }
                    else
                    {
                        string thickness = GetField("FinalThickness_mm")?.Text;
                        string sheets = GetField("SheetsProduced")?.Text;
                        query = $@"
                            INSERT INTO FinishedBatch (BatchNumber, SemiFinishedID, GradeID, UnitID, ProcessingDateTime, FinalThickness_mm, SheetsProduced, Status)
                            VALUES ('{batchNumber}', 1, 3, 2, GETDATE(), {thickness}, {sheets}, 'На складе')";
                    }

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Запись успешно добавлена", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}