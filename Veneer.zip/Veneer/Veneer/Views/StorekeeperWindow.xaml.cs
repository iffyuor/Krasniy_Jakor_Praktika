﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Veneer.DataAccess;
using Veneer.Helpers;

namespace Veneer.Views
{
    public partial class StorekeeperWindow : Window
    {
        public StorekeeperWindow()
        {
            InitializeComponent();
            txtUserInfo.Text = SessionManager.CurrentUser.FullName + " | Кладовщик";
            LoadSuppliers();
            LoadLogs();
            LoadVeneer();
            LoadSemi();
            LoadFinished();
        }

        private void LoadSuppliers()
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT SupplierID, SupplierName FROM Supplier";
                var adapter = new SqlDataAdapter(query, conn);
                var dt = new DataTable();
                adapter.Fill(dt);
                cmbSupplier.ItemsSource = dt.DefaultView;
                if (dt.Rows.Count > 0)
                    cmbSupplier.SelectedIndex = 0;
            }
        }

        private async void LoadLogs()
        {
            try
            {
                DataTable dt = new DataTable();
                await Task.Run(() =>
                {
                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();
                        string query = "SELECT BatchNumber, QuantityReceived as 'Объём м³', QualityClass as 'Сорт', ReceiptDate as 'Дата', Status FROM LogBatch WHERE Status = 'На складе' ORDER BY ReceiptDate DESC";
                        var adapter = new SqlDataAdapter(query, conn);
                        adapter.Fill(dt);
                    }
                });
                dgLogs.ItemsSource = dt.DefaultView;
                dgLogs.AutoGenerateColumns = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private async void LoadVeneer()
        {
            try
            {
                DataTable dt = new DataTable();
                await Task.Run(() =>
                {
                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();
                        string query = "SELECT BatchNumber, SheetsProduced as 'Кол-во листов', Thickness_mm as 'Толщина мм', ProductionDate as 'Дата', Status FROM VeneerBatch WHERE Status = 'На складе' ORDER BY ProductionDate DESC";
                        var adapter = new SqlDataAdapter(query, conn);
                        adapter.Fill(dt);
                    }
                });
                dgVeneer.ItemsSource = dt.DefaultView;
                dgVeneer.AutoGenerateColumns = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private async void LoadSemi()
        {
            try
            {
                DataTable dt = new DataTable();
                await Task.Run(() =>
                {
                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();
                        string query = "SELECT BatchNumber, SheetsProduced as 'Кол-во листов', LayersCount as 'Слоёв', PressingDateTime as 'Дата', Status FROM SemiFinishedBatch WHERE Status = 'На складе' ORDER BY PressingDateTime DESC";
                        var adapter = new SqlDataAdapter(query, conn);
                        adapter.Fill(dt);
                    }
                });
                dgSemi.ItemsSource = dt.DefaultView;
                dgSemi.AutoGenerateColumns = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private async void LoadFinished()
        {
            try
            {
                DataTable dt = new DataTable();
                await Task.Run(() =>
                {
                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();
                        string query = "SELECT BatchNumber, SheetsProduced as 'Кол-во листов', FinalThickness_mm as 'Толщина мм', ProcessingDateTime as 'Дата', Status FROM FinishedBatch WHERE Status = 'На складе' ORDER BY ProcessingDateTime DESC";
                        var adapter = new SqlDataAdapter(query, conn);
                        adapter.Fill(dt);
                    }
                });
                dgFinished.ItemsSource = dt.DefaultView;
                dgFinished.AutoGenerateColumns = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void BtnOrder_Click(object sender, RoutedEventArgs e)
        {
            string quantityText = txtQuantity.Text.Trim();

            if (string.IsNullOrEmpty(quantityText))
            {
                MessageBox.Show("Введите объём брёвен", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!decimal.TryParse(quantityText, out decimal quantity))
            {
                MessageBox.Show("Введите корректное число", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (cmbSupplier.SelectedValue == null)
            {
                MessageBox.Show("Выберите поставщика", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int supplierId = Convert.ToInt32(cmbSupplier.SelectedValue);
            string newBatchNumber = GetNextBatchNumber();

            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = @"INSERT INTO LogBatch (BatchNumber, SupplierID, TimberTypeID, UnitID, QuantityReceived, QualityClass, ReceiptDate, Status)
                                VALUES (@BatchNumber, @SupplierId, 1, 1, @Quantity, 1, GETDATE(), 'На складе')";
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@BatchNumber", newBatchNumber);
                cmd.Parameters.AddWithValue("@SupplierId", supplierId);
                cmd.Parameters.AddWithValue("@Quantity", quantity);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show($"Заказано {quantity} м³ брёвен. Партия: {newBatchNumber}", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            txtQuantity.Clear();
            LoadLogs();
        }

        private string GetNextBatchNumber()
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT ISNULL(MAX(CAST(REPLACE(BatchNumber, 'БРЕВНО-', '') AS INT)), 0) + 1 FROM LogBatch WHERE BatchNumber LIKE 'БРЕВНО-%'";
                var cmd = new SqlCommand(query, conn);
                int nextNum = Convert.ToInt32(cmd.ExecuteScalar());
                return "БРЕВНО-" + nextNum.ToString("D3");
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            SessionManager.Clear();
            new MainWindow().Show();
            Close();
        }
    }
}