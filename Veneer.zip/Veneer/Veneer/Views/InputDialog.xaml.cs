﻿using System.Windows;

namespace Veneer.Views
{
    public partial class InputDialog : Window
    {
        public string InputValue { get; private set; }

        public InputDialog(string prompt, string title = "Ввод данных", string defaultValue = "")
        {
            InitializeComponent();
            Title = title;
            lblPrompt.Text = prompt;
            txtInput.Text = defaultValue;
            txtInput.Focus();
        }

        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            InputValue = txtInput.Text.Trim();
            if (string.IsNullOrEmpty(InputValue))
            {
                MessageBox.Show("Введите значение", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            DialogResult = true;
            Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            InputValue = null;
            DialogResult = false;
            Close();
        }
    }
}