﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Veneer.DataAccess;
using Veneer.Helpers;

namespace Veneer.Views
{
    public partial class OperatorWindow : Window
    {
        public OperatorWindow()
        {
            InitializeComponent();
            txtUserInfo.Text = SessionManager.CurrentUser.FullName + " | Оператор";
            LoadTasks();
        }

        private async void LoadTasks()
        {
            try
            {
                DataTable dt = new DataTable();
                await Task.Run(() =>
                {
                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();
                        string query = @"
    SELECT 'Цех 1' as Этап, 'Бревно' as Тип, BatchNumber as Партия, QuantityReceived as Количество, 'м^3' as ЕдИзм, Status 
    FROM LogBatch WHERE Status = 'На складе'
    UNION ALL
    SELECT 'Цех 2', 'Шпон', BatchNumber, SheetsProduced, 'шт', Status 
    FROM VeneerBatch WHERE Status = 'На складе'
    UNION ALL
    SELECT 'Цех 3', 'Полуфабрикат', BatchNumber, SheetsProduced, 'шт', Status 
    FROM SemiFinishedBatch WHERE Status = 'На складе'
    UNION ALL
    SELECT 'Отгрузка', 'Фанера', BatchNumber, SheetsProduced, 'шт', Status 
    FROM FinishedBatch WHERE Status = 'На складе'";
                        var adapter = new SqlDataAdapter(query, conn);
                        adapter.Fill(dt);
                    }
                });

                dgTasks.ItemsSource = dt.DefaultView;
                dgTasks.AutoGenerateColumns = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        // Цех 1: Бревно → Шпон (1 м³ = 200 листов)
        private async void BtnWorkshop1_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new InputDialog("Выберите бревно:", "Цех 1 - Переработка бревна", "");
            dialog.Owner = this;
            if (dialog.ShowDialog() == true && !string.IsNullOrEmpty(dialog.InputValue))
            {
                await Task.Run(() => ProcessLogToVeneer(dialog.InputValue));
                LoadTasks();
            }
        }

        private void ProcessLogToVeneer(string batchNumber)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();

                // Получаем данные бревна
                string selectQuery = "SELECT LogBatchID, QuantityReceived FROM LogBatch WHERE BatchNumber = @BatchNumber AND Status = 'На складе'";
                var selectCmd = new SqlCommand(selectQuery, conn);
                selectCmd.Parameters.AddWithValue("@BatchNumber", batchNumber);
                var reader = selectCmd.ExecuteReader();

                if (!reader.Read())
                {
                    MessageBox.Show("Бревно не найдено или уже обработано");
                    reader.Close();
                    return;
                }

                int logId = reader.GetInt32(0);
                decimal volume = reader.GetDecimal(1);
                reader.Close();

                // Обновляем статус бревна
                string updateQuery = "UPDATE LogBatch SET Status = 'Обработано' WHERE BatchNumber = @BatchNumber";
                var updateCmd = new SqlCommand(updateQuery, conn);
                updateCmd.Parameters.AddWithValue("@BatchNumber", batchNumber);
                updateCmd.ExecuteNonQuery();

                // Создаём шпон (1 м³ = 200 листов)
                int sheets = (int)(volume * 200);
                string newBatchNumber = GetNextBatchNumber("VeneerBatch", "ШПОН");

                string insertQuery = @"INSERT INTO VeneerBatch (BatchNumber, LogBatchID, UnitID, Thickness_mm, SheetsProduced, ProductionDate, OperatorID, Status)
                                      VALUES (@BatchNumber, @LogId, 2, 1.5, @Sheets, GETDATE(), 3, 'На складе')";
                var insertCmd = new SqlCommand(insertQuery, conn);
                insertCmd.Parameters.AddWithValue("@BatchNumber", newBatchNumber);
                insertCmd.Parameters.AddWithValue("@LogId", logId);
                insertCmd.Parameters.AddWithValue("@Sheets", sheets);
                insertCmd.ExecuteNonQuery();

                MessageBox.Show($"Бревно '{batchNumber}' ({volume} м³) переработано в '{newBatchNumber}' ({sheets} листов шпона)", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // Цех 2: Шпон → Полуфабрикат (200 листов шпона = 20 листов полуфабриката)
        private async void BtnWorkshop2_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new InputDialog("Выберите шпон:", "Цех 2 - Переработка шпона", "");
            dialog.Owner = this;
            if (dialog.ShowDialog() == true && !string.IsNullOrEmpty(dialog.InputValue))
            {
                await Task.Run(() => ProcessVeneerToSemi(dialog.InputValue));
                LoadTasks();
            }
        }

        private void ProcessVeneerToSemi(string batchNumber)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();

                string selectQuery = "SELECT VeneerBatchID, SheetsProduced FROM VeneerBatch WHERE BatchNumber = @BatchNumber AND Status = 'На складе'";
                var selectCmd = new SqlCommand(selectQuery, conn);
                selectCmd.Parameters.AddWithValue("@BatchNumber", batchNumber);
                var reader = selectCmd.ExecuteReader();

                if (!reader.Read())
                {
                    MessageBox.Show("Шпон не найден или уже обработан");
                    reader.Close();
                    return;
                }

                int veneerId = reader.GetInt32(0);
                int sheets = reader.GetInt32(1);
                reader.Close();

                string updateQuery = "UPDATE VeneerBatch SET Status = 'Обработано' WHERE BatchNumber = @BatchNumber";
                var updateCmd = new SqlCommand(updateQuery, conn);
                updateCmd.Parameters.AddWithValue("@BatchNumber", batchNumber);
                updateCmd.ExecuteNonQuery();

                // 200 листов шпона = 20 листов полуфабриката
                int semiSheets = (sheets / 200) * 20;
                string newBatchNumber = GetNextBatchNumber("SemiFinishedBatch", "ПОЛУ");

                string insertQuery = @"INSERT INTO SemiFinishedBatch (BatchNumber, VeneerBatchID, UnitID, PressingDateTime, LayersCount, GlueType, Pressure_atm, Temperature_C, SheetsProduced, OperatorID, Status)
                                      VALUES (@BatchNumber, @VeneerId, 2, GETDATE(), 10, 'СФК', 12, 150, @Sheets, 3, 'На складе')";
                var insertCmd = new SqlCommand(insertQuery, conn);
                insertCmd.Parameters.AddWithValue("@BatchNumber", newBatchNumber);
                insertCmd.Parameters.AddWithValue("@VeneerId", veneerId);
                insertCmd.Parameters.AddWithValue("@Sheets", semiSheets);
                insertCmd.ExecuteNonQuery();

                MessageBox.Show($"Шпон '{batchNumber}' ({sheets} листов) переработан в '{newBatchNumber}' ({semiSheets} листов полуфабриката)", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // Цех 3: Полуфабрикат → Фанера (с потерями 5%)
        private async void BtnWorkshop3_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new InputDialog("Выберите полуфабрикат:", "Цех 3 - Переработка полуфабриката", "");
            dialog.Owner = this;
            if (dialog.ShowDialog() == true && !string.IsNullOrEmpty(dialog.InputValue))
            {
                await Task.Run(() => ProcessSemiToFinished(dialog.InputValue));
                LoadTasks();
            }
        }

        private void ProcessSemiToFinished(string batchNumber)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();

                string selectQuery = "SELECT SemiFinishedID, SheetsProduced FROM SemiFinishedBatch WHERE BatchNumber = @BatchNumber AND Status = 'На складе'";
                var selectCmd = new SqlCommand(selectQuery, conn);
                selectCmd.Parameters.AddWithValue("@BatchNumber", batchNumber);
                var reader = selectCmd.ExecuteReader();

                if (!reader.Read())
                {
                    MessageBox.Show("Полуфабрикат не найден или уже обработан");
                    reader.Close();
                    return;
                }

                int semiId = reader.GetInt32(0);
                int sheets = reader.GetInt32(1);
                reader.Close();

                string updateQuery = "UPDATE SemiFinishedBatch SET Status = 'Обработано' WHERE BatchNumber = @BatchNumber";
                var updateCmd = new SqlCommand(updateQuery, conn);
                updateCmd.Parameters.AddWithValue("@BatchNumber", batchNumber);
                updateCmd.ExecuteNonQuery();

                // Потери 5%
                int finishedSheets = (int)(sheets * 0.95);
                string newBatchNumber = GetNextBatchNumber("FinishedBatch", "ФАНЕРА");

                string insertQuery = @"INSERT INTO FinishedBatch (BatchNumber, SemiFinishedID, GradeID, UnitID, ProcessingDateTime, FinalThickness_mm, SheetsProduced, Status)
                                      VALUES (@BatchNumber, @SemiId, 2, 2, GETDATE(), 10, @Sheets, 'На складе')";
                var insertCmd = new SqlCommand(insertQuery, conn);
                insertCmd.Parameters.AddWithValue("@BatchNumber", newBatchNumber);
                insertCmd.Parameters.AddWithValue("@SemiId", semiId);
                insertCmd.Parameters.AddWithValue("@Sheets", finishedSheets);
                insertCmd.ExecuteNonQuery();

                MessageBox.Show($"Полуфабрикат '{batchNumber}' ({sheets} листов) переработан в '{newBatchNumber}' ({finishedSheets} листов фанеры)", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // Отгрузка фанеры на склад (меняем статус)
        private async void BtnShip_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new InputDialog("Выберите фанеру для отгрузки на склад:", "Отгрузка", "");
            dialog.Owner = this;
            if (dialog.ShowDialog() == true && !string.IsNullOrEmpty(dialog.InputValue))
            {
                await Task.Run(() => ShipToWarehouse(dialog.InputValue));
                LoadTasks();
            }
        }

        private void ShipToWarehouse(string batchNumber)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();

                string updateQuery = "UPDATE FinishedBatch SET Status = 'Отгружена', ShippingDate = GETDATE() WHERE BatchNumber = @BatchNumber AND Status = 'На складе'";
                var updateCmd = new SqlCommand(updateQuery, conn);
                updateCmd.Parameters.AddWithValue("@BatchNumber", batchNumber);
                int rows = updateCmd.ExecuteNonQuery();

                if (rows > 0)
                {
                    MessageBox.Show($"Фанера '{batchNumber}' отгружена на склад готовой продукции", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show($"Фанера '{batchNumber}' не найдена или уже отгружена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
        }

        private string GetNextBatchNumber(string tableName, string prefix)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = $"SELECT ISNULL(MAX(CAST(REPLACE(BatchNumber, '{prefix}-', '') AS INT)), 0) + 1 FROM {tableName} WHERE BatchNumber LIKE '{prefix}-%'";
                var cmd = new SqlCommand(query, conn);
                int nextNum = Convert.ToInt32(cmd.ExecuteScalar());
                return $"{prefix}-{nextNum:D3}";
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            SessionManager.Clear();
            new MainWindow().Show();
            Close();
        }
    }
}