﻿using System;
using System.Data;
using System.Windows;
using System.Data.SqlClient;
using Veneer.DataAccess;

namespace Veneer.Views
{
    public partial class AdminUserEditWindow : Window
    {
        private int _userId = 0;
        private bool _isEdit = false;

        public AdminUserEditWindow(int userId = 0)
        {
            InitializeComponent();
            _userId = userId;
            _isEdit = userId > 0;

            LoadRoles();

            if (_isEdit)
            {
                LoadUser();
                Title = "Редактирование пользователя";
            }
            else
            {
                Title = "Добавление пользователя";
            }
        }

        private void LoadRoles()
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT RoleID, RoleName FROM Role";
                var adapter = new SqlDataAdapter(query, conn);
                var dt = new DataTable();
                adapter.Fill(dt);

                cmbRole.ItemsSource = dt.DefaultView;
                cmbRole.DisplayMemberPath = "RoleName";
                cmbRole.SelectedValuePath = "RoleID";

                if (dt.Rows.Count > 0)
                    cmbRole.SelectedIndex = 0;
            }
        }

        private void LoadUser()
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT Login, FullName, RoleID, IsActive FROM AppUser WHERE UserID = @UserId";
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@UserId", _userId);
                var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtLogin.Text = reader["Login"].ToString();
                    txtFullName.Text = reader["FullName"]?.ToString() ?? "";
                    cmbRole.SelectedValue = reader["RoleID"];
                    chkActive.IsChecked = Convert.ToBoolean(reader["IsActive"]);
                }
            }
        }

        private bool IsLoginExists(string login, int excludeUserId = 0)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM AppUser WHERE Login = @Login AND UserID != @ExcludeUserId";
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Login", login);
                cmd.Parameters.AddWithValue("@ExcludeUserId", excludeUserId);
                return (int)cmd.ExecuteScalar() > 0;
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            string fullName = txtFullName.Text.Trim();
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Password;

            if (cmbRole.SelectedValue == null)
            {
                MessageBox.Show("Выберите роль", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int roleId = Convert.ToInt32(cmbRole.SelectedValue);
            bool isActive = chkActive.IsChecked == true;

            if (string.IsNullOrEmpty(login))
            {
                MessageBox.Show("Введите логин", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrEmpty(fullName))
            {
                MessageBox.Show("Введите ФИО", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!_isEdit && IsLoginExists(login, 0))
            {
                MessageBox.Show("Логин уже существует", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();

                if (_isEdit)
                {
                    string query = "UPDATE AppUser SET Login=@Login, FullName=@FullName, RoleID=@RoleId, IsActive=@IsActive WHERE UserID=@UserId";
                    var cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@UserId", _userId);
                    cmd.Parameters.AddWithValue("@Login", login);
                    cmd.Parameters.AddWithValue("@FullName", fullName);
                    cmd.Parameters.AddWithValue("@RoleId", roleId);
                    cmd.Parameters.AddWithValue("@IsActive", isActive);
                    cmd.ExecuteNonQuery();

                    if (!string.IsNullOrEmpty(password))
                    {
                        string pwdQuery = "UPDATE AppUser SET PasswordHash=@Password WHERE UserID=@UserId";
                        var pwdCmd = new SqlCommand(pwdQuery, conn);
                        pwdCmd.Parameters.AddWithValue("@UserId", _userId);
                        pwdCmd.Parameters.AddWithValue("@Password", password);
                        pwdCmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    string query = @"INSERT INTO AppUser (EmployeeID, RoleID, Login, FullName, PasswordHash, IsActive, CreatedDate)
                                    VALUES (1, @RoleId, @Login, @FullName, @Password, @IsActive, GETDATE())";
                    var cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Login", login);
                    cmd.Parameters.AddWithValue("@FullName", fullName);
                    cmd.Parameters.AddWithValue("@RoleId", roleId);
                    cmd.Parameters.AddWithValue("@Password", string.IsNullOrEmpty(password) ? "123" : password);
                    cmd.Parameters.AddWithValue("@IsActive", isActive);
                    cmd.ExecuteNonQuery();
                }
            }

            DialogResult = true;
            Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}