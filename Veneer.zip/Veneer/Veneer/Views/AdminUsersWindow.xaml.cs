﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Data.SqlClient;
using Veneer.DataAccess;

namespace Veneer.Views
{
    public partial class AdminUsersWindow : Window
    {
        public AdminUsersWindow()
        {
            InitializeComponent();
            LoadUsers();
        }

        private void LoadUsers()
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                // Убираем JOIN с Employee, берём FullName прямо из AppUser
                string query = @"
                    SELECT u.UserID, u.Login, r.RoleName, u.FullName as EmployeeName, 
                           CASE WHEN u.IsActive = 1 THEN 'Активен' ELSE 'Заблокирован' END AS Status
                    FROM AppUser u
                    JOIN Role r ON u.RoleID = r.RoleID
                    ORDER BY u.UserID";

                var adapter = new SqlDataAdapter(query, conn);
                var dt = new DataTable();
                adapter.Fill(dt);
                dgUsers.ItemsSource = dt.DefaultView;
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var window = new AdminUserEditWindow();
            window.Owner = this;
            if (window.ShowDialog() == true)
            {
                LoadUsers();
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (dgUsers.SelectedItem == null)
            {
                MessageBox.Show("Выберите пользователя", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var row = (DataRowView)dgUsers.SelectedItem;
            int userId = Convert.ToInt32(row["UserID"]);

            var window = new AdminUserEditWindow(userId);
            window.Owner = this;
            if (window.ShowDialog() == true)
            {
                LoadUsers();
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgUsers.SelectedItem == null)
            {
                MessageBox.Show("Выберите пользователя", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var row = (DataRowView)dgUsers.SelectedItem;
            int userId = Convert.ToInt32(row["UserID"]);
            string login = row["Login"].ToString();

            if (MessageBox.Show($"Удалить пользователя '{login}'?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = "DELETE FROM AppUser WHERE UserID = @UserId";
                    var cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    cmd.ExecuteNonQuery();
                }
                LoadUsers();
            }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}