﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Veneer.DataAccess;
using Veneer.Helpers;

namespace Veneer.Views
{
    public partial class TechnologistWindow : Window
    {
        public TechnologistWindow()
        {
            InitializeComponent();
            txtUserInfo.Text = SessionManager.CurrentUser.FullName + " | Технолог";
            LoadEquipment();
            LoadPlan();
            LoadHistory();
            LoadStock();
        }

        // ==================== 1. ОБОРУДОВАНИЕ ====================

        private async void LoadEquipment()
        {
            try
            {
                DataTable dt = new DataTable();
                await Task.Run(() =>
                {
                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();
                        string query = "SELECT EquipmentID, EquipmentName, WorkshopID, Status, LastCheckDate, ProblemDescription FROM Equipment ORDER BY WorkshopID, EquipmentID";
                        var adapter = new SqlDataAdapter(query, conn);
                        adapter.Fill(dt);
                    }
                });
                dgEquipment.ItemsSource = dt.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void BtnRefreshEquipment_Click(object sender, RoutedEventArgs e)
        {
            LoadEquipment();
        }

        private void BtnCheckEquipment_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            int equipmentId = Convert.ToInt32(btn.Tag);

            var dialog = new InputDialog("Введите статус (работает / не работает):", "Проверка оборудования", "");
            dialog.Owner = this;
            if (dialog.ShowDialog() != true) return;

            string status = dialog.InputValue.ToLower();

            if (status == "работает" || status == "работает" || status == "норма" || status == "хорошо")
            {
                UpdateEquipmentStatus(equipmentId, "Работает", null);
                MessageBox.Show("Оборудование исправно", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else if (status == "не работает" || status == "неработает" || status == "сломан" || status == "поломка")
            {
                var problemDialog = new InputDialog("Опишите проблему:", "Неисправность", "");
                problemDialog.Owner = this;
                if (problemDialog.ShowDialog() == true)
                {
                    UpdateEquipmentStatus(equipmentId, "Не работает", problemDialog.InputValue);
                    MessageBox.Show("Неисправность зафиксирована", "Успех", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Введите 'работает' или 'не работает'", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnRepairEquipment_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            int equipmentId = Convert.ToInt32(btn.Tag);

            UpdateEquipmentStatus(equipmentId, "Работает", null);
            MessageBox.Show("Оборудование отремонтировано", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void UpdateEquipmentStatus(int equipmentId, string status, string problem)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = @"UPDATE Equipment 
                                SET Status = @Status, LastCheckDate = GETDATE(), ProblemDescription = @Problem 
                                WHERE EquipmentID = @EquipmentId";
                var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Status", status);
                cmd.Parameters.AddWithValue("@Problem", problem ?? "");
                cmd.Parameters.AddWithValue("@EquipmentId", equipmentId);
                cmd.ExecuteNonQuery();
            }
            LoadEquipment();
        }

        // ==================== 2. ПЛАН ПРОИЗВОДСТВА ====================

        private async void LoadPlan()
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = "SELECT TOP 1 PlanID, TargetVeneerSheets, TargetSemiSheets, TargetFinishedSheets FROM ProductionPlan WHERE IsActive = 1 ORDER BY PlanDate DESC";
                    var cmd = new SqlCommand(query, conn);
                    var reader = await cmd.ExecuteReaderAsync();

                    if (reader.Read())
                    {
                        txtTargetVeneer.Text = reader.GetInt32(1).ToString();
                        txtTargetSemi.Text = reader.GetInt32(2).ToString();
                        txtTargetFinished.Text = reader.GetInt32(3).ToString();
                    }
                    reader.Close();
                }
                await UpdateProgress();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private async Task UpdateProgress()
        {
            try
            {
                int targetVeneer = int.TryParse(txtTargetVeneer.Text, out int v) ? v : 1;
                int targetSemi = int.TryParse(txtTargetSemi.Text, out int s) ? s : 1;
                int targetFinished = int.TryParse(txtTargetFinished.Text, out int f) ? f : 1;

                int actualVeneer = 0;
                int actualSemi = 0;
                int actualFinished = 0;

                await Task.Run(() =>
                {
                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();

                        // Весь произведённый шпон
                        string veneerQuery = "SELECT ISNULL(SUM(SheetsProduced), 0) FROM VeneerBatch";
                        actualVeneer = Convert.ToInt32(new SqlCommand(veneerQuery, conn).ExecuteScalar());

                        // Весь произведённый полуфабрикат
                        string semiQuery = "SELECT ISNULL(SUM(SheetsProduced), 0) FROM SemiFinishedBatch";
                        actualSemi = Convert.ToInt32(new SqlCommand(semiQuery, conn).ExecuteScalar());

                        // Вся произведённая фанера (независимо от статуса)
                        string finishedQuery = "SELECT ISNULL(SUM(SheetsProduced), 0) FROM FinishedBatch";
                        actualFinished = Convert.ToInt32(new SqlCommand(finishedQuery, conn).ExecuteScalar());
                    }
                });

                progressVeneer.Value = targetVeneer > 0 ? Math.Min(100, actualVeneer * 100 / targetVeneer) : 0;
                progressSemi.Value = targetSemi > 0 ? Math.Min(100, actualSemi * 100 / targetSemi) : 0;
                progressFinished.Value = targetFinished > 0 ? Math.Min(100, actualFinished * 100 / targetFinished) : 0;
            }
            catch (Exception ex)
            {
                // Игнорируем ошибки прогресса
            }
        }

        private async void LoadStock()
        {
            try
            {
                DataTable dt = new DataTable();
                await Task.Run(() =>
                {
                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();
                        string query = @"
                            SELECT 'Брёвна' as Тип, ISNULL(SUM(QuantityReceived), 0) as Количество, 'м3' as ЕдИзм
                            FROM LogBatch WHERE Status = 'На складе'
                            UNION ALL
                            SELECT 'Шпон', ISNULL(SUM(SheetsProduced), 0), 'шт'
                            FROM VeneerBatch WHERE Status = 'На складе'
                            UNION ALL
                            SELECT 'Полуфабрикат', ISNULL(SUM(SheetsProduced), 0), 'шт'
                            FROM SemiFinishedBatch WHERE Status = 'На складе'
                            UNION ALL
                            SELECT 'Готовая фанера', ISNULL(SUM(SheetsProduced), 0), 'шт'
                            FROM FinishedBatch WHERE Status = 'На складе'";
                        var adapter = new SqlDataAdapter(query, conn);
                        adapter.Fill(dt);
                    }
                });
                dgStock.ItemsSource = dt.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private async void BtnSavePlan_Click(object sender, RoutedEventArgs e)
        {
            int targetVeneer = int.TryParse(txtTargetVeneer.Text, out int v) ? v : 0;
            int targetSemi = int.TryParse(txtTargetSemi.Text, out int s) ? s : 0;
            int targetFinished = int.TryParse(txtTargetFinished.Text, out int f) ? f : 0;

            await Task.Run(() =>
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();

                    string deactivateQuery = "UPDATE ProductionPlan SET IsActive = 0 WHERE IsActive = 1";
                    new SqlCommand(deactivateQuery, conn).ExecuteNonQuery();

                    string insertQuery = @"INSERT INTO ProductionPlan (TargetVeneerSheets, TargetSemiSheets, TargetFinishedSheets, PlanDate, IsActive)
                                          VALUES (@Veneer, @Semi, @Finished, GETDATE(), 1)";
                    var cmd = new SqlCommand(insertQuery, conn);
                    cmd.Parameters.AddWithValue("@Veneer", targetVeneer);
                    cmd.Parameters.AddWithValue("@Semi", targetSemi);
                    cmd.Parameters.AddWithValue("@Finished", targetFinished);
                    cmd.ExecuteNonQuery();
                }
            });

            MessageBox.Show("План сохранён", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            await UpdateProgress();
            LoadStock();
        }

        // ==================== 3. ИСТОРИЯ ====================
        private async void LoadHistory()
        {
            try
            {
                DataTable dt = new DataTable();
                await Task.Run(() =>
                {
                    using (var conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();
                        string query = @"
                    SELECT 'Бревно' as Тип, BatchNumber as Партия, QuantityReceived as Количество, 'м3' as ЕдИзм, ReceiptDate as Дата, Status 
                    FROM LogBatch
                    UNION ALL
                    SELECT 'Шпон', BatchNumber, SheetsProduced, 'шт', ProductionDate, Status 
                    FROM VeneerBatch
                    UNION ALL
                    SELECT 'Полуфабрикат', BatchNumber, SheetsProduced, 'шт', PressingDateTime, Status 
                    FROM SemiFinishedBatch
                    UNION ALL
                    SELECT 'Фанера', BatchNumber, SheetsProduced, 'шт', ProcessingDateTime, Status 
                    FROM FinishedBatch";
                        var adapter = new SqlDataAdapter(query, conn);
                        adapter.Fill(dt);
                    }
                });

                // Сортируем после заполнения
                DataView dv = dt.DefaultView;
                dv.Sort = "Дата DESC";
                dgHistory.ItemsSource = dv;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void CmbFilterType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilter();
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFilter();
        }

        private void ApplyFilter()
        {
            // Проверяем что DataGrid и его ItemsSource существуют
            if (dgHistory == null || dgHistory.ItemsSource == null) return;

            var view = dgHistory.ItemsSource as DataView;
            if (view == null) return;

            string filterType = (cmbFilterType.SelectedItem as ComboBoxItem)?.Content.ToString();
            string searchText = txtSearch.Text.Trim();

            string filter = "";
            if (filterType != "Все" && !string.IsNullOrEmpty(filterType))
            {
                filter = $"Тип = '{filterType}'";
            }

            if (!string.IsNullOrEmpty(searchText))
            {
                if (!string.IsNullOrEmpty(filter)) filter += " AND ";
                filter += $"Партия LIKE '%{searchText}%'";
            }

            view.RowFilter = filter;
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            SessionManager.Clear();
            new MainWindow().Show();
            Close();
        }
    }
}