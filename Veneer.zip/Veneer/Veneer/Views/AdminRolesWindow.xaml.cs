﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using Veneer.DataAccess;

namespace Veneer.Views
{
    public partial class AdminRolesWindow : Window
    {
        public AdminRolesWindow()
        {
            InitializeComponent();
            LoadRoles();
        }

        private void LoadRoles()
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT RoleID, RoleName FROM Role ORDER BY RoleID";
                var adapter = new System.Data.SqlClient.SqlDataAdapter(query, conn);
                var dt = new DataTable();
                adapter.Fill(dt);
                dgRoles.ItemsSource = dt.DefaultView;
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var window = new AdminRoleEditWindow();
            window.Owner = this;
            if (window.ShowDialog() == true)
            {
                LoadRoles();
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (dgRoles.SelectedItem == null)
            {
                MessageBox.Show("Выберите роль для редактирования", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var row = (DataRowView)dgRoles.SelectedItem;
            int roleId = Convert.ToInt32(row["RoleID"]);
            string roleName = row["RoleName"].ToString();

            var window = new AdminRoleEditWindow(roleId, roleName);
            window.Owner = this;
            if (window.ShowDialog() == true)
            {
                LoadRoles();
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgRoles.SelectedItem == null)
            {
                MessageBox.Show("Выберите роль для удаления", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var row = (DataRowView)dgRoles.SelectedItem;
            int roleId = Convert.ToInt32(row["RoleID"]);
            string roleName = row["RoleName"].ToString();

            if (MessageBox.Show($"Удалить роль '{roleName}'?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = "DELETE FROM Role WHERE RoleID = @RoleId";
                    var cmd = new System.Data.SqlClient.SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@RoleId", roleId);
                    cmd.ExecuteNonQuery();
                }
                LoadRoles();
            }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}