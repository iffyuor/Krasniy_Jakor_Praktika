﻿using System;
using System.Windows;
using Veneer.DataAccess;

namespace Veneer.Views
{
    public partial class AdminRoleEditWindow : Window
    {
        private int _roleId = 0;
        private bool _isEdit = false;

        public AdminRoleEditWindow(int roleId = 0, string roleName = "")
        {
            InitializeComponent();
            _roleId = roleId;
            _isEdit = roleId > 0;

            if (_isEdit)
            {
                txtRoleName.Text = roleName;
                Title = "Редактирование роли";
            }
            else
            {
                Title = "Добавление роли";
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            string roleName = txtRoleName.Text.Trim();

            if (string.IsNullOrEmpty(roleName))
            {
                MessageBox.Show("Введите название роли", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();

                if (_isEdit)
                {
                    string query = "UPDATE Role SET RoleName = @RoleName WHERE RoleID = @RoleId";
                    var cmd = new System.Data.SqlClient.SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@RoleId", _roleId);
                    cmd.Parameters.AddWithValue("@RoleName", roleName);
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    string query = "INSERT INTO Role (RoleName) VALUES (@RoleName)";
                    var cmd = new System.Data.SqlClient.SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@RoleName", roleName);
                    cmd.ExecuteNonQuery();
                }
            }

            DialogResult = true;
            Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}