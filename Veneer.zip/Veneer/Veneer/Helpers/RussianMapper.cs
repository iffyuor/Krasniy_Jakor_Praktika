﻿using System.Collections.Generic;
using System.Data;
using System.Windows.Controls;

namespace Veneer.Helpers
{
    public static class RussianMapper
    {
        public static void SetRussianHeaders(DataGrid grid, DataTable dt)
        {
            grid.AutoGenerateColumns = false;
            grid.Columns.Clear();

            foreach (DataColumn column in dt.Columns)
            {
                DataGridTextColumn col = new DataGridTextColumn();
                col.Header = GetHeader(column.ColumnName);
                col.Binding = new System.Windows.Data.Binding(column.ColumnName);
                col.Width = 130;
                grid.Columns.Add(col);
            }
        }

        private static string GetHeader(string columnName)
        {
            var dict = new Dictionary<string, string>
            {
                { "BatchNumber", "Номер партии" },
                { "LogBatchID", "ID партии бревна" },
                { "VeneerBatchID", "ID партии шпона" },
                { "SemiFinishedID", "ID полуфабриката" },
                { "FinishedID", "ID готовой продукции" },
                { "SupplierID", "Поставщик" },
                { "TimberTypeID", "Вид древесины" },
                { "UnitID", "Ед. измерения" },
                { "QuantityReceived", "Объём, м³" },
                { "QualityClass", "Сорт" },
                { "ReceiptDate", "Дата приёмки" },
                { "DefectTypeID", "Тип брака" },
                { "DefectQuantity", "Кол-во брака" },
                { "Thickness_mm", "Толщина, мм" },
                { "SheetsProduced", "Кол-во листов" },
                { "ProductionDate", "Дата производства" },
                { "OperatorID", "Оператор" },
                { "LayersCount", "Слоёв" },
                { "GlueType", "Марка клея" },
                { "Pressure_atm", "Давление, атм" },
                { "Temperature_C", "Температура, °C" },
                { "PressingDateTime", "Дата прессования" },
                { "ProcessingDateTime", "Дата обработки" },
                { "FinalThickness_mm", "Толщина, мм" },
                { "SandingType", "Шлифовка" },
                { "ShippingDate", "Дата отгрузки" },
                { "Customer", "Покупатель" },
                { "Status", "Статус" },
                { "Login", "Логин" },
                { "FullName", "ФИО" },
                { "RoleName", "Роль" },
                { "IsActive", "Активен" },
                { "DefectName", "Вид брака" },
                { "GradeName", "Сорт" },
                { "TypeName", "Вид древесины" },
                { "BrandName", "Марка клея" },
                { "Quantity", "Количество" },
                { "ProductType", "Тип продукции" },
                { "BatchID", "ID партии" }
            };

            return dict.ContainsKey(columnName) ? dict[columnName] : columnName;
        }
    }
}