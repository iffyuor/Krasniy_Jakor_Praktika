﻿using System.Collections.Generic;

namespace Veneer.Helpers
{
    public static class TextMapper
    {
        private static Dictionary<string, string> roleNames = new Dictionary<string, string>
        {
            { "Admin", "Администратор" },
            { "Technologist", "Технолог" },
            { "Operator", "Оператор" },
            { "Storekeeper", "Кладовщик" }
        };

        private static Dictionary<string, string> statuses = new Dictionary<string, string>
        {
            { "На складе", "На складе" },
            { "Переработано", "Переработано" },
            { "Произведён", "Произведён" },
            { "Использован", "Использован" },
            { "Готов", "Готов" },
            { "Брак", "Брак" },
            { "Отгружена", "Отгружена" },
            { "На проверке", "На проверке" },
            { "Передан в отделку", "Передан в отделку" }
        };

        public static string GetRoleName(string englishName)
        {
            if (roleNames.ContainsKey(englishName))
                return roleNames[englishName];
            return englishName;
        }

        public static string GetStatus(string englishStatus)
        {
            if (statuses.ContainsKey(englishStatus))
                return statuses[englishStatus];
            return englishStatus;
        }
    }
}