﻿using Veneer.Models;

namespace Veneer.Helpers
{
    public static class SessionManager
    {
        public static User CurrentUser { get; set; }

        public static void Clear()
        {
            CurrentUser = null;
        }
    }
}